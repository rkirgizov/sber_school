-- Ежемесячно создавать отчет о задолжниках (отрицательное значение счета) с указанием клиента и
-- менеджера, который этот долг должен взыскивать. Также в отчете должны быть паспортные данные клиентов.
with 
    clients as (    -- собираем клиентов по учётной записи
        select
            accounts.account_id,
            clients.last_name,
            clients.first_name,
            clients.patronymic
        from 
            kela_dwh_dim_accounts_hist accounts
        inner join
            kela_dwh_dim_clients_hist clients
            on accounts.client = clients.client_id
        where
            clients.is_deleted = '0'    -- отбираем актуальные записи
            and current_date between clients.valid_from and clients.valid_to),   
    managers as (    -- собираем менеджеров по учётной записи
        select
            accounts.account_id,
            managers.last_name,
            managers.first_name,
            managers.patronymic
        from 
            kela_dwh_dim_accounts_hist accounts
        inner join
            kela_dwh_dim_managers_hist managers
            on accounts.manager = managers.manager_id
        where
            managers.is_deleted = '0'    -- отбираем актуальные записи
            and current_date between managers.valid_from and managers.valid_to)   
select
    extract(month from accounts.valid_from) as report_month,
    accounts.value,
    case 
        when 
            clients.last_name is not null
        then 
            clients.last_name || ' ' || clients.first_name || ' ' || clients.patronymic || ' (id ' || clients.account_id || ')'
        else 
            '-'
    end as client,
    case
        when
            clients.last_name is not null
        then
            passports.passport_number || ' выдан ' || passports.passport_date || ' ' || passports.passport_issue
        else
            '-'
        end as passport,    
    case 
        when 
            managers.last_name is not null
        then 
            managers.last_name || ' ' || managers.first_name || ' ' || managers.patronymic
        else 
            '-'
    end as manager
from
    kela_dwh_dim_accounts_hist accounts
left join      -- left join - попытка избежать потери отрицательного аккаунта, если у него нет актуального клиента
    clients
    on accounts.account_id = clients.account_id
left join      -- как и с клиентом
    managers
    on accounts.account_id = managers.account_id
left join      -- ориентировочно для паспортов
    kela_dwh_dim_passports passports
    on clients.last_name = passports.last_name
        and clients.first_name = passports.first_name
        and clients.patronymic = passports.patronymic
where
    1=1
    and accounts.value < 0
    and accounts.valid_from         -- выбираем за определённую дату
            between to_date('2021-05', 'YYYY-MM')       
            and last_day (to_date('2021-05', 'YYYY-MM'))
order by
    accounts.valid_from;


-- Для проверки закрыл записи, если клиент или менеджер будет нулевым (в майских), работает
update 
    kela_dwh_dim_managers_hist
set 
    valid_to = to_date('2021-02-09', 'YYYY-MM-DD')
where
    last_name = 'Ейкина' and first_name = 'Рената'; 
update 
    kela_dwh_dim_clients_hist
set 
    valid_to = to_date('2021-02-09', 'YYYY-MM-DD')
where
    last_name = 'Ссорина' and first_name = 'Наиля'; 