-------------------------------------------------------------------------------------------------
-- payment_logs - фактовая таблица
-------------------------------------------------------------------------------------------------
-- очищаем временное хранилище
truncate table kela_stg_payment_logs;
-- заполняем основное временное хранилище
insert into 
    kela_stg_payment_logs (PHONE, PAYMENT_SOURCE, SALES_POINT, VALUE, CREATE_DT)
select 
    PHONE, PAYMENT_SOURCE, SALES_POINT, VALUE, CREATE_DT
from 
    baratin.payment_logs
where 
    CREATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_FCT_PAYMENT_LOGS');
-- передаём новые данные по платежам в целевую таблицу фактов платежей
insert into 
    kela_dwh_fct_payment_logs (PHONE, PAYMENT_SOURCE, SALES_POINT, VALUE, CREATE_DT)
select
    PHONE, PAYMENT_SOURCE, SALES_POINT, VALUE, CREATE_DT
from 
    kela_stg_payment_logs;
-- обновляем метаданные
update 
    kela_meta
set 
    update_date = coalesce ( 
            (select 
                max (CREATE_DT) 
            from 
                kela_stg_payment_logs
            where 
                schema_name = 'DE3AT' 
                and table_name = 'KELA_DWH_FCT_PAYMENT_LOGS'),
            update_date)
where
    schema_name = 'DE3AT' 
    and table_name = 'KELA_DWH_FCT_PAYMENT_LOGS';
-- подтверждаем все изменения
commit;
-------------------------------------------------------------------------------------------------
-- phones -> payment_logs (phone_num <- phone) 
-------------------------------------------------------------------------------------------------
-- очищаем временные хранилища
truncate table kela_stg_phones;
truncate table kela_stg_phones_del;
-- заполняем основное временное хранилище
insert into 
    kela_stg_phones (PHONE_NUM, ACCOUNT, RATE, CREATE_DT, UPDATE_DT)
select 
    PHONE_NUM, ACCOUNT, RATE, CREATE_DT, UPDATE_DT
from 
    baratin.phones
where 
    UPDATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_DIM_PHONES_HIST')
    or CREATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_DIM_PHONES_HIST');
-- собираем все имеющиеся на данный момент id в источниках
insert into kela_stg_phones_del (PHONE_NUM) select PHONE_NUM from baratin.phones;
-- закрываем изменённые записи (дату) и добавляем новые
merge into 
    kela_dwh_dim_phones_hist tgt
using 
    kela_stg_phones stg
    on (tgt.PHONE_NUM = stg.PHONE_NUM)
when 
    matched -- закрываем изменившиеся записи
        then 
            update 
                set 
                    valid_to = stg.update_dt - interval '1' day
                where 
                    current_date between tgt.valid_from and tgt.valid_to
                    and (1=0  
                    or stg.ACCOUNT <> tgt.ACCOUNT
                    or stg.RATE <> tgt.RATE)
when not matched -- добавляем новые записи
    then 
        insert (
            PHONE_NUM,
            ACCOUNT,
            RATE,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            ) 
        values (
            stg.PHONE_NUM,
            stg.ACCOUNT,
            stg.RATE,
            coalesce(stg.UPDATE_DT, stg.CREATE_DT),
            to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
            '0'
            );
-- добавляем новую версию изменённых записей
insert into 
    kela_dwh_dim_phones_hist (
            PHONE_NUM,
            ACCOUNT,
            RATE,
            VALID_FROM,
            VALID_TO,
            IS_DELETED)
select 
    stg.PHONE_NUM,
    stg.ACCOUNT,
    stg.RATE,
    coalesce(stg.UPDATE_DT, stg.CREATE_DT),
    to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
    '0'
from 
    kela_dwh_dim_phones_hist tgt 
inner join                                    
    kela_stg_phones stg
    on tgt.phone_num = stg.phone_num
where
    current_date > tgt.valid_to     -- по идее берём из стэйджа данные по закрытой записи из таргета (нет действующей записи), 
    and (1=0                        -- то есть, если запись в таргете закрыта, а в стэйдже есть запись с таким айдишником, то надо добавить её, как версию закрытой
    or stg.ACCOUNT <> tgt.ACCOUNT
    or stg.RATE <> tgt.RATE);
-- добавляем версию удалённых записей в целевую таблицу
insert into 
    kela_dwh_dim_phones_hist (
            PHONE_NUM,
            ACCOUNT,
            RATE,
            VALID_FROM,
            VALID_TO,
            IS_DELETED)
select -- Отбираем удалённые из источника записи
    PHONE_NUM,
    ACCOUNT,
    RATE,
    current_date,
    to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
    '1'
from
    kela_dwh_dim_phones_hist 
where   
    current_date between valid_from and valid_to    -- последняя действующая запись
    and is_deleted = '0'                            -- избегаем дублирования версий удалённых записей
    and PHONE_NUM in (
        select 
            tgt.PHONE_NUM
        from 
            kela_dwh_dim_phones_hist tgt 
        left join                                   -- при левом джойне id во временном хранилище будет нулевым 
            kela_stg_phones_del stg
            on tgt.PHONE_NUM = stg.PHONE_NUM
        where
            stg.PHONE_NUM is null );
-- обновляем конечную дату валидности у удалённых записей
update 
    kela_dwh_dim_phones_hist
set 
    valid_to = current_date - interval '1' day -- ставим вчерашнюю дату, так как не знаем даты удаления
where   
    current_date between valid_from and valid_to    -- последняя действующая запись
    and is_deleted = '0'                            -- отсекаем добавленную ранее версию удалённой записи
    and PHONE_NUM in (
        select 
            tgt.PHONE_NUM
        from 
            kela_dwh_dim_phones_hist tgt 
        left join                                   -- при левом джойне id во временном хранилище будет нулевым 
            kela_stg_phones_del stg
            on tgt.PHONE_NUM = stg.PHONE_NUM
        where
            stg.PHONE_NUM is null );
-- обновляем метаданные
update 
    kela_meta
set 
    update_date = coalesce ( 
            (select 
                max (coalesce(stg.UPDATE_DT, stg.CREATE_DT)) 
            from 
                kela_stg_phones stg
            where 
                schema_name = 'DE3AT' 
                and table_name = 'KELA_DWH_DIM_PHONES_HIST'),
            update_date)
where
    schema_name = 'DE3AT' 
    and table_name = 'KELA_DWH_DIM_PHONES_HIST';
-- подтверждаем все изменения
commit;
-------------------------------------------------------------------------------------------------
-- accounts -> phones (ACCOUNT_ID <- ACCOUNT) 
-------------------------------------------------------------------------------------------------
-- очищаем временные хранилища
truncate table kela_stg_accounts;
truncate table kela_stg_accounts_del;
-- заполняем основное временное хранилище
insert into 
    kela_stg_accounts (ACCOUNT_ID, VALUE, CLIENT, MANAGER, CREATE_DT, UPDATE_DT)
select 
    ACCOUNT_ID, VALUE, CLIENT, MANAGER, CREATE_DT, UPDATE_DT
from 
    baratin.accounts
where 
    UPDATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_DIM_ACCOUNTS_HIST')
    or CREATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_DIM_ACCOUNTS_HIST');
-- собираем все имеющиеся на данный момент id в источниках
insert into kela_stg_accounts_del (ACCOUNT_ID) select ACCOUNT_ID from baratin.accounts;
-- закрываем изменённые записи (дату) и добавляем новые
merge into 
    kela_dwh_dim_accounts_hist tgt
using 
    kela_stg_accounts stg
    on (tgt.ACCOUNT_ID = stg.ACCOUNT_ID)
when 
    matched -- закрываем изменившиеся записи
        then 
            update 
                set 
                    valid_to = stg.update_dt - interval '1' day
                where 
                    current_date between tgt.valid_from and tgt.valid_to
                    and (1=0  
                    or stg.VALUE <> tgt.VALUE
                    or stg.CLIENT <> tgt.CLIENT
                    or stg.MANAGER <> tgt.MANAGER)
when not matched -- добавляем новые записи
    then 
        insert (
            ACCOUNT_ID, 
            VALUE,
            CLIENT, 
            MANAGER,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            ) 
        values (
            stg.ACCOUNT_ID,
            stg.VALUE,
            stg.CLIENT,
            stg.MANAGER,
            coalesce(stg.UPDATE_DT, stg.CREATE_DT),
            to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
            '0'
            );
-- добавляем новую версию изменённых записей
insert into 
    kela_dwh_dim_accounts_hist (
            ACCOUNT_ID, 
            VALUE,
            CLIENT, 
            MANAGER,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            )
select 
    stg.ACCOUNT_ID,
    stg.VALUE,
    stg.CLIENT,
    stg.MANAGER,
    coalesce(stg.UPDATE_DT, stg.CREATE_DT),
    to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
    '0'
from 
    kela_dwh_dim_accounts_hist tgt 
inner join                                    
    kela_stg_accounts stg
    on tgt.ACCOUNT_ID = stg.ACCOUNT_ID
where
    current_date > tgt.valid_to     -- по идее берём из стэйджа данные по закрытой записи из таргета (нет действующей записи), 
    and (1=0                        -- то есть, если запись в таргете закрыта, а в стэйдже есть запись с таким айдишником, то надо добавить её, как версию закрытой
    or stg.VALUE <> tgt.VALUE
    or stg.CLIENT <> tgt.CLIENT
    or stg.MANAGER <> tgt.MANAGER);
-- добавляем версию удалённых записей в целевую таблицу
insert into 
    kela_dwh_dim_accounts_hist (
            ACCOUNT_ID, 
            VALUE,
            CLIENT, 
            MANAGER,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            )
select -- Отбираем удалённые из источника записи
    ACCOUNT_ID, 
    VALUE,
    CLIENT, 
    MANAGER,
    current_date,
    to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
    '1'
from
    kela_dwh_dim_accounts_hist 
where   
    current_date between valid_from and valid_to    -- последняя действующая запись
    and is_deleted = '0'                            -- избегаем дублирования версий удалённых записей
    and ACCOUNT_ID in (
        select 
            tgt.ACCOUNT_ID
        from 
            kela_dwh_dim_accounts_hist tgt 
        left join                                   -- при левом джойне id во временном хранилище будет нулевым 
            kela_stg_accounts_del stg
            on tgt.ACCOUNT_ID = stg.ACCOUNT_ID
        where
            stg.ACCOUNT_ID is null );
-- обновляем конечную дату валидности у удалённых записей
update 
    kela_dwh_dim_accounts_hist
set 
    valid_to = current_date - interval '1' day -- ставим вчерашнюю дату, так как не знаем даты удаления
where   
    current_date between valid_from and valid_to    -- последняя действующая запись
    and is_deleted = '0'                            -- отсекаем добавленную ранее версию удалённой записи
    and ACCOUNT_ID in (
        select 
            tgt.ACCOUNT_ID
        from 
            kela_dwh_dim_accounts_hist tgt 
        left join                                   -- при левом джойне id во временном хранилище будет нулевым 
            kela_stg_accounts_del stg
            on tgt.ACCOUNT_ID = stg.ACCOUNT_ID
        where
            stg.ACCOUNT_ID is null );
-- обновляем метаданные
update 
    kela_meta
set 
    update_date = coalesce ( 
            (select 
                max (coalesce(stg.UPDATE_DT, stg.CREATE_DT)) 
            from 
                kela_stg_accounts stg
            where 
                schema_name = 'DE3AT' 
                and table_name = 'KELA_DWH_DIM_ACCOUNTS_HIST'),
            update_date)
where
    schema_name = 'DE3AT' 
    and table_name = 'KELA_DWH_DIM_ACCOUNTS_HIST';
-- подтверждаем все изменения
commit;
-------------------------------------------------------------------------------------------------
-- clients -> accounts (client_id <- client) 
-------------------------------------------------------------------------------------------------
-- очищаем временные хранилища
truncate table kela_stg_clients;
truncate table kela_stg_clients_del;
-- заполняем основное временное хранилище
insert into 
    kela_stg_clients (CLIENT_ID, FIRST_NAME, LAST_NAME, PATRONYMIC, SEX, DATE_OF_BIRTH, CREATE_DT, UPDATE_DT)
select 
    CLIENT_ID, FIRST_NAME, LAST_NAME, PATRONYMIC, SEX, DATE_OF_BIRTH, CREATE_DT, UPDATE_DT
from 
    baratin.clients
where 
    UPDATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_DIM_CLIENTS_HIST')
    or CREATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_DIM_CLIENTS_HIST');
-- собираем все имеющиеся на данный момент id в источниках
insert into kela_stg_clients_del (CLIENT_ID) select CLIENT_ID from baratin.clients;
-- закрываем изменённые записи (дату) и добавляем новые
merge into 
    kela_dwh_dim_clients_hist tgt
using 
    kela_stg_clients stg
    on (tgt.CLIENT_ID = stg.CLIENT_ID)
when 
    matched -- закрываем изменившиеся записи
        then 
            update 
                set 
                    valid_to = stg.update_dt - interval '1' day
                where 
                    current_date between tgt.valid_from and tgt.valid_to
                    and (1=0  
                    or stg.FIRST_NAME <> tgt.FIRST_NAME
                    or stg.LAST_NAME <> tgt.LAST_NAME
                    or stg.PATRONYMIC <> tgt.PATRONYMIC
                    or stg.SEX <> tgt.SEX
                    or stg.DATE_OF_BIRTH <> tgt.DATE_OF_BIRTH)
when not matched -- добавляем новые записи
    then 
        insert (
            CLIENT_ID,
            FIRST_NAME,
            LAST_NAME,
            PATRONYMIC,
            SEX,
            DATE_OF_BIRTH,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            ) 
        values (
            stg.CLIENT_ID,
            stg.FIRST_NAME,
            stg.LAST_NAME,
            stg.PATRONYMIC,
            stg.SEX,
            stg.DATE_OF_BIRTH,
            coalesce(stg.UPDATE_DT, stg.CREATE_DT),
            to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
            '0'
            );
-- добавляем новую версию изменённых записей
insert into 
    kela_dwh_dim_clients_hist (
            CLIENT_ID,
            FIRST_NAME,
            LAST_NAME,
            PATRONYMIC,
            SEX,
            DATE_OF_BIRTH,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            )
select 
    stg.CLIENT_ID,
    stg.FIRST_NAME,
    stg.LAST_NAME,
    stg.PATRONYMIC,
    stg.SEX,
    stg.DATE_OF_BIRTH,
    coalesce(stg.UPDATE_DT, stg.CREATE_DT),
    to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
    '0'
from 
    kela_dwh_dim_clients_hist tgt 
inner join                                    
    kela_stg_clients stg
    on tgt.CLIENT_ID = stg.CLIENT_ID
where
    current_date > tgt.valid_to     -- по идее берём из стэйджа данные по закрытой записи из таргета (нет действующей записи), 
    and (1=0                        -- то есть, если запись в таргете закрыта, а в стэйдже есть запись с таким айдишником, то надо добавить её, как версию закрытой
        or stg.FIRST_NAME <> tgt.FIRST_NAME
        or stg.LAST_NAME <> tgt.LAST_NAME
        or stg.PATRONYMIC <> tgt.PATRONYMIC
        or stg.SEX <> tgt.SEX
        or stg.DATE_OF_BIRTH <> tgt.DATE_OF_BIRTH);
-- добавляем версию удалённых записей в целевую таблицу
insert into 
    kela_dwh_dim_clients_hist (
            CLIENT_ID,
            FIRST_NAME,
            LAST_NAME,
            PATRONYMIC,
            SEX,
            DATE_OF_BIRTH,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            )
select -- Отбираем удалённые из источника записи
    CLIENT_ID,
    FIRST_NAME,
    LAST_NAME,
    PATRONYMIC,
    SEX,
    DATE_OF_BIRTH,
    current_date,
    to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
    '1'
from
    kela_dwh_dim_clients_hist 
where   
    current_date between valid_from and valid_to    -- последняя действующая запись
    and is_deleted = '0'                            -- избегаем дублирования версий удалённых записей
    and CLIENT_ID in (
        select 
            tgt.CLIENT_ID
        from 
            kela_dwh_dim_clients_hist tgt 
        left join                                   -- при левом джойне id во временном хранилище будет нулевым 
            kela_stg_clients_del stg
            on tgt.CLIENT_ID = stg.CLIENT_ID
        where
            stg.CLIENT_ID is null );
-- обновляем конечную дату валидности у удалённых записей
update 
    kela_dwh_dim_clients_hist
set 
    valid_to = current_date - interval '1' day -- ставим вчерашнюю дату, так как не знаем даты удаления
where   
    current_date between valid_from and valid_to    -- последняя действующая запись
    and is_deleted = '0'                            -- отсекаем добавленную ранее версию удалённой записи
    and CLIENT_ID in (
        select 
            tgt.CLIENT_ID
        from 
            kela_dwh_dim_clients_hist tgt 
        left join                                   -- при левом джойне id во временном хранилище будет нулевым 
            kela_stg_clients_del stg
            on tgt.CLIENT_ID = stg.CLIENT_ID
        where
            stg.CLIENT_ID is null );
-- обновляем метаданные
update 
    kela_meta
set 
    update_date = coalesce ( 
            (select 
                max (coalesce(stg.UPDATE_DT, stg.CREATE_DT)) 
            from 
                kela_stg_clients stg
            where 
                schema_name = 'DE3AT' 
                and table_name = 'KELA_DWH_DIM_CLIENTS_HIST'),
            update_date)
where
    schema_name = 'DE3AT' 
    and table_name = 'KELA_DWH_DIM_CLIENTS_HIST';
-- подтверждаем все изменения
commit;
-------------------------------------------------------------------------------------------------
-- managers -> accounts (manager_id <- manager) 
-------------------------------------------------------------------------------------------------
-- очищаем временные хранилища
truncate table kela_stg_managers;
truncate table kela_stg_managers_del;
-- заполняем основное временное хранилище
insert into 
    kela_stg_managers (MANAGER_ID, FIRST_NAME, LAST_NAME, PATRONYMIC, SALES_POINT, CREATE_DT, UPDATE_DT, SALARY)
select 
    MANAGER_ID, FIRST_NAME, LAST_NAME, PATRONYMIC, SALES_POINT, CREATE_DT, UPDATE_DT, SALARY
from 
    baratin.managers
where 
    UPDATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_DIM_MANAGERS_HIST')
    or CREATE_DT > (select update_date from kela_meta where schema_name = 'DE3AT' and table_name = 'KELA_DWH_DIM_MANAGERS_HIST');
-- собираем все имеющиеся на данный момент id в источниках
insert into kela_stg_managers_del (MANAGER_ID) select MANAGER_ID from baratin.managers;
-- закрываем изменённые записи (дату) и добавляем новые
merge into 
    kela_dwh_dim_managers_hist tgt
using 
    kela_stg_managers stg
    on (tgt.MANAGER_ID = stg.MANAGER_ID)
when 
    matched -- закрываем изменившиеся записи
        then 
            update 
                set 
                    valid_to = stg.update_dt - interval '1' day
                where 
                    current_date between tgt.valid_from and tgt.valid_to
                    and (1=0  
                    or stg.FIRST_NAME <> tgt.FIRST_NAME
                    or stg.LAST_NAME <> tgt.LAST_NAME
                    or stg.PATRONYMIC <> tgt.PATRONYMIC
                    or stg.SALES_POINT <> tgt.SALES_POINT
                    or stg.SALARY <> tgt.SALARY)
when not matched -- добавляем новые записи
    then 
        insert (
            MANAGER_ID,
            FIRST_NAME,
            LAST_NAME,
            PATRONYMIC,
            SALES_POINT,
            SALARY,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            ) 
        values (
            stg.MANAGER_ID,
            stg.FIRST_NAME,
            stg.LAST_NAME,
            stg.PATRONYMIC,
            stg.SALES_POINT,
            stg.SALARY,
            coalesce(stg.UPDATE_DT, stg.CREATE_DT),
            to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
            '0'
            );
-- добавляем новую версию изменённых записей
insert into 
    kela_dwh_dim_managers_hist (
            MANAGER_ID,
            FIRST_NAME,
            LAST_NAME,
            PATRONYMIC,
            SALES_POINT,
            SALARY,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            )
select 
    stg.MANAGER_ID,
    stg.FIRST_NAME,
    stg.LAST_NAME,
    stg.PATRONYMIC,
    stg.SALES_POINT,
    stg.SALARY,
    coalesce(stg.UPDATE_DT, stg.CREATE_DT),
    to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
    '0'
from 
    kela_dwh_dim_managers_hist tgt 
inner join                                    
    kela_stg_managers stg
    on tgt.MANAGER_ID = stg.MANAGER_ID
where
    current_date > tgt.valid_to     -- по идее берём из стэйджа данные по закрытой записи из таргета (нет действующей записи), 
    and (1=0                        -- то есть, если запись в таргете закрыта, а в стэйдже есть запись с таким айдишником, то надо добавить её, как версию закрытой
        or stg.FIRST_NAME <> tgt.FIRST_NAME
        or stg.LAST_NAME <> tgt.LAST_NAME
        or stg.PATRONYMIC <> tgt.PATRONYMIC
        or stg.SALES_POINT <> tgt.SALES_POINT
        or stg.SALARY <> tgt.SALARY);
-- добавляем версию удалённых записей в целевую таблицу
insert into 
    kela_dwh_dim_managers_hist (
            MANAGER_ID,
            FIRST_NAME,
            LAST_NAME,
            PATRONYMIC,
            SALES_POINT,
            SALARY,
            VALID_FROM,
            VALID_TO,
            IS_DELETED
            )
select -- Отбираем удалённые из источника записи
    MANAGER_ID,
    FIRST_NAME,
    LAST_NAME,
    PATRONYMIC,
    SALES_POINT,
    SALARY,
    current_date,
    to_date('31.12.2999 23:59:59','DD.MM.YYYY HH24:MI:SS'),
    '1'
from
    kela_dwh_dim_managers_hist 
where   
    current_date between valid_from and valid_to    -- последняя действующая запись
    and is_deleted = '0'                            -- избегаем дублирования версий удалённых записей
    and MANAGER_ID in (
        select 
            tgt.MANAGER_ID
        from 
            kela_dwh_dim_managers_hist tgt 
        left join                                   -- при левом джойне id во временном хранилище будет нулевым 
            kela_stg_managers_del stg
            on tgt.MANAGER_ID = stg.MANAGER_ID
        where
            stg.MANAGER_ID is null );
-- обновляем конечную дату валидности у удалённых записей
update 
    kela_dwh_dim_managers_hist
set 
    valid_to = current_date - interval '1' day -- ставим вчерашнюю дату, так как не знаем даты удаления
where   
    current_date between valid_from and valid_to    -- последняя действующая запись
    and is_deleted = '0'                            -- отсекаем добавленную ранее версию удалённой записи
    and MANAGER_ID in (
        select 
            tgt.MANAGER_ID
        from 
            kela_dwh_dim_managers_hist tgt 
        left join                                   -- при левом джойне id во временном хранилище будет нулевым 
            kela_stg_managers_del stg
            on tgt.MANAGER_ID = stg.MANAGER_ID
        where
            stg.MANAGER_ID is null );
-- обновляем метаданные
update 
    kela_meta
set 
    update_date = coalesce ( 
            (select 
                max (coalesce(stg.UPDATE_DT, stg.CREATE_DT)) 
            from 
                kela_stg_managers stg
            where 
                schema_name = 'DE3AT' 
                and table_name = 'KELA_DWH_DIM_MANAGERS_HIST'),
            update_date)
where
    schema_name = 'DE3AT' 
    and table_name = 'KELA_DWH_DIM_MANAGERS_HIST';
-- подтверждаем все изменения
commit;