 -- Ежедневно строить витрину данных о поступлении денег от каждого клиента.
with 
    clients as (    -- собираем клиентов по телефону
        select 
            phones.phone_num,
            clients.last_name,
            clients.first_name,
            clients.patronymic
        from 
            kela_dwh_dim_phones_hist phones
        inner join
            kela_dwh_dim_accounts_hist accounts
            on phones.account = accounts.account_id
        inner join
            kela_dwh_dim_clients_hist clients
            on accounts.client = clients.client_id
        where
            current_date between clients.valid_from and clients.valid_to)   -- отбираем актуальные записи
select
    trunc(pl.create_dt) as report_date,     -- trunc, так как время платежей разное
    sum(pl.value) as value_sum,
    cl.last_name,
    cl.first_name,
    cl.patronymic
from
    kela_dwh_fct_payment_logs pl
inner join
    clients cl
    on pl.phone = cl.phone_num
where
    create_dt       -- выбираем за определённую дату
        between to_date('2021-02-09 00:00:01', 'YYYY-MM-DD HH24:MI:SS') 
        and to_date('2021-02-09 23:59:59', 'YYYY-MM-DD HH24:MI:SS')
group by
    trunc(pl.create_dt),
    cl.last_name,
    cl.first_name,
    cl.patronymic
order by 
    cl.last_name,
    cl.first_name, 
    cl.patronymic;