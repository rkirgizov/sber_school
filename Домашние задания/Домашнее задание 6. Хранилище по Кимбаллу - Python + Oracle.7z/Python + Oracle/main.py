#! /usr/bin/env python3
import subprocess as sub

sub.Popen(['python3', 'py_scripts/dml_main.py'])
sub.Popen(['python3', 'py_scripts/dml_passport.py'])
