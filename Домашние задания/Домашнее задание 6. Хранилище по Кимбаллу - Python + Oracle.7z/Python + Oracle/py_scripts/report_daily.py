#! /usr/bin/env python3
import utils as ut

date_ = input('Дата отчёта(YYYY-MM-DD): ')
print('Try to open report')
ut.sqlReportByDate('../sql_scripts/rep_daily_baratin.sql', date_ + '00:00:01', date_ + '23:59:59')
