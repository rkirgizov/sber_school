with 
    clients as (    
        select 
            phones.phone_num,
            clients.last_name,
            clients.first_name,
            clients.patronymic
        from 
            kela_dwh_dim_phones_hist phones
        inner join
            kela_dwh_dim_accounts_hist accounts
            on phones.account = accounts.account_id
        inner join
            kela_dwh_dim_clients_hist clients
            on accounts.client = clients.client_id
        where
            current_date between clients.valid_from and clients.valid_to)   
select
    trunc(pl.create_dt) as report_date,
    sum(pl.value) as value_sum,
    cl.last_name,
    cl.first_name,
    cl.patronymic
from
    kela_dwh_fct_payment_logs pl
inner join
    clients cl
    on pl.phone = cl.phone_num
where
    create_dt
        between to_date('{0}', 'YYYY-MM-DD HH24:MI:SS') 
        and to_date('{1}', 'YYYY-MM-DD HH24:MI:SS')
group by
    trunc(pl.create_dt),
    cl.last_name,
    cl.first_name,
    cl.patronymic
order by 
    cl.last_name,
    cl.first_name, 
    cl.patronymic
