-- создаём таблицу с метаданными, инициируем первичные даты обновления
create table kela_meta (
    schema_name varchar(30),
    table_name varchar(30),
    update_date date
);
insert into 
    kela_meta (schema_name, table_name, update_date)
values
    ('DE3AT', 'KELA_DWH_FCT_PAYMENT_LOGS', date'1900-01-01');
insert into 
    kela_meta (schema_name, table_name, update_date)
values
    ('DE3AT', 'KELA_DWH_DIM_PHONES_HIST', date'1900-01-01');
insert into 
    kela_meta (schema_name, table_name, update_date)
values
    ('DE3AT', 'KELA_DWH_DIM_ACCOUNTS_HIST', date'1900-01-01');
insert into 
    kela_meta (schema_name, table_name, update_date)
values
    ('DE3AT', 'KELA_DWH_DIM_CLIENTS_HIST', date'1900-01-01');
insert into 
    kela_meta (schema_name, table_name, update_date)
values
    ('DE3AT', 'KELA_DWH_DIM_MANAGERS_HIST', date'1900-01-01');
-- создаём временные хранилища
create table 
    kela_stg_payment_logs as ( 
        select * from baratin.payment_logs where 1=0);
create table 
    kela_stg_phones as ( 
        select * from baratin.phones where 1=0);
create table 
    kela_stg_accounts as ( 
        select * from baratin.accounts where 1=0);
create table 
    kela_stg_clients as ( 
        select * from baratin.clients where 1=0);
create table 
    kela_stg_managers as ( 
        select * from baratin.managers where 1=0);
create table 
    kela_stg_passports (
        LAST_NAME	    varchar2(50),
        FIRST_NAME	    varchar2(50),
        PATRONYMIC	    varchar2(50),
        SEX	            varchar2(10),
        DATE_OF_BIRTH	    date,
        PASSPORT_NUMBER	    varchar2(11),
        PASSPORT_DATE	    date,
        PASSPORT_ISSUE	    varchar2(200)
        );
-- создаём временные хранилища для контроля удалений
create table    
    kela_stg_phones_del as (
        select PHONE_NUM from kela_stg_phones where 1=0);
create table    
    kela_stg_accounts_del as (
        select ACCOUNT_ID from kela_stg_accounts where 1=0);
create table    
    kela_stg_clients_del as (
        select CLIENT_ID from kela_stg_clients where 1=0);
create table    
    kela_stg_managers_del as (
        select MANAGER_ID from kela_stg_managers where 1=0);
-- создаём целевые таблицы
create table 
    kela_dwh_fct_payment_logs (
        PHONE           char(12),
        PAYMENT_SOURCE  number,
        SALES_POINT	    number,
        VALUE	        number(18, 5),
        CREATE_DT	    date
        );
create table 
    kela_dwh_dim_phones_hist ( 
        PHONE_NUM       char(12),
        ACCOUNT	        number,
        RATE	        number,
        VALID_FROM	    date,
        VALID_TO	    date,
        IS_DELETED      char(1)
        );
create table 
    kela_dwh_dim_accounts_hist ( 
        ACCOUNT_ID	    number,
        VALUE	        number(18, 5),
        CLIENT	        number,
        MANAGER	        number,
        VALID_FROM	    date,
        VALID_TO	    date,
        IS_DELETED      char(1)
        );
create table 
    kela_dwh_dim_clients_hist (
        CLIENT_ID	    number,
        FIRST_NAME	    varchar2(50),
        LAST_NAME	    varchar2(50),
        PATRONYMIC	    varchar2(50),
        SEX	            char(1),
        DATE_OF_BIRTH	date,
        VALID_FROM	    date,
        VALID_TO	    date,
        IS_DELETED      char(1)
        );
create table 
    kela_dwh_dim_managers_hist ( 
        MANAGER_ID	    number,
        FIRST_NAME	    varchar2(50),
        LAST_NAME	    varchar2(50),
        PATRONYMIC	    varchar2(50),
        SALES_POINT	    number,
        SALARY	        number,
        VALID_FROM	    date,
        VALID_TO	    date,
        IS_DELETED      char(1)
        );
create table 
    kela_dwh_dim_passports (
        FIRST_NAME	    varchar2(50),
        LAST_NAME	    varchar2(50),
        PATRONYMIC	    varchar2(50),
        SEX	            char(1),
        DATE_OF_BIRTH	date,
        PASSPORT_NUMBER	varchar2(11),
        PASSPORT_DATE	date,
        PASSPORT_ISSUE	varchar2(200)
        );
