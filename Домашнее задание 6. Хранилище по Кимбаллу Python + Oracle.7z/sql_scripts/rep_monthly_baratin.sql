with
    clients as (
        select
            accounts.account_id,
            clients.last_name,
            clients.first_name,
            clients.patronymic
        from
            kela_dwh_dim_accounts_hist accounts
        inner join
            kela_dwh_dim_clients_hist clients
            on accounts.client = clients.client_id
        where
            clients.is_deleted = '0'
            and current_date between clients.valid_from and clients.valid_to),
    managers as (
        select
            accounts.account_id,
            managers.last_name,
            managers.first_name,
            managers.patronymic
        from
            kela_dwh_dim_accounts_hist accounts
        inner join
            kela_dwh_dim_managers_hist managers
            on accounts.manager = managers.manager_id
        where
            managers.is_deleted = '0'
            and current_date between managers.valid_from and managers.valid_to)
select
    extract(month from accounts.valid_from) as report_month,
    accounts.value,
    case
        when
            clients.last_name is not null
        then
            clients.last_name || ' ' || clients.first_name || ' ' || clients.patronymic || ' (id ' || clients.account_id || ')'
        else
            '-'
    end as client,
    case
        when
            clients.last_name is not null
        then
            passports.passport_number || ' выдан ' || passports.passport_date || ' ' || passports.passport_issue
        else
            '-'
        end as passport,
    case
        when
            managers.last_name is not null
        then
            managers.last_name || ' ' || managers.first_name || ' ' || managers.patronymic
        else
            '-'
    end as manager
from
    kela_dwh_dim_accounts_hist accounts
left join
    clients
    on accounts.account_id = clients.account_id
left join
    managers
    on accounts.account_id = managers.account_id
left join
    kela_dwh_dim_passports passports
    on clients.last_name = passports.last_name
        and clients.first_name = passports.first_name
        and clients.patronymic = passports.patronymic
where
    1=1
    and accounts.value < 0
    and accounts.valid_from
            between to_date('{0}', 'YYYY-MM')
            and last_day (to_date('{1}', 'YYYY-MM'))
order by
    accounts.valid_from
