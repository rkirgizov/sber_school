#! /usr/bin/env python3
import sys
import subprocess as sub

sys.path.insert(1, '/home/de3at/kela/baratin/py_scripts')
import utils as ut

print('Выберите тип отчёта')
print('(1) Платежи за день')
print('(2) Отрицательные счета')
typeReport = input('Введите 1 или 2: ')

if typeReport == '1':
    date_ = input('Дата отчёта(YYYY-MM-DD): ')
    print('Try to open report')
    ut.sqlReportByDate('sql_scripts/rep_daily_baratin.sql', date_ + '00:00:01', date_ + '23:59:59')
elif typeReport == '2':
    date_ = input('Месяц отчёта(YYYY-MM): ')
    print('Try to open report')
    ut.sqlReportByDate('sql_scripts/rep_monthly_baratin.sql', date_, date_)
else:
    print('Неверный ввод')
