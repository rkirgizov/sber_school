#! /usr/bin/env python3
import utils as ut

print('Try to execute DML')
try:
    ut.executeScriptsFromFile('/home/de3at/kela/baratin/sql_scripts/dml_baratin.sql')
except Exception as e:
    print('!ERROR!: {0}'.format(e))
else:
    print('DML executed')
