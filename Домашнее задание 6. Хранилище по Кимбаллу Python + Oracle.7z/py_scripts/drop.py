#! /usr/bin/env python3
import utils as ut

print('Try to execute DROP')
try:
    ut.executeScriptsFromFile('../sql_scripts/drop_baratin.sql')
except Exception as e:
    print('!ERROR!: {0}'.format(e))
else:
    print('DROP executed')
