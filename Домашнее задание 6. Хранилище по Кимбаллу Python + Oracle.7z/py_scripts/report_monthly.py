#! /usr/bin/env python3
import utils as ut

date_ = input('Месяц отчёта(YYYY-MM): ')
print('Try to open report')
ut.sqlReportByDate('../sql_scripts/rep_monthly_baratin.sql', date_, date_)
