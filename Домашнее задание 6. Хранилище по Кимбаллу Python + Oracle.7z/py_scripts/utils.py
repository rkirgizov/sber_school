#!/usr/bin/env python3
import jaydebeapi
import pandas

def sqlReportByDate (filename, date_from, date_to):
    with jaydebeapi.connect(
                'oracle.jdbc.driver.OracleDriver',
                'jdbc:oracle:thin:de3at/bardthebowman@de-oracle.chronosavant.ru:1521/deoracle',
                ['de3at','bardthebowman'],
                '/home/de3at/ojdbc8.jar') as conn:

        # Open and read the file as a single buffer
        fd = open(filename, 'r')
        sqlFile = fd.read()
        fd.close
        sql = sqlFile.format(date_from, date_to)
        try:                
            df = pandas.read_sql(sql, conn)
            print(df)
        except jaydebeapi.DatabaseError as exc:
            print(sql)
            raise
        except Exception:
            raise

def executeScriptFromFileWithVar(filename, date_from, date_to):

    with jaydebeapi.connect(
                'oracle.jdbc.driver.OracleDriver',
                'jdbc:oracle:thin:de3at/bardthebowman@de-oracle.chronosavant.ru:1521/deoracle',
                ['de3at','bardthebowman'],
                '/home/de3at/ojdbc8.jar') as conn:

        with conn.cursor() as curs:
            # Open and read the file as a single buffer
            fd = open(filename, 'r')
            sqlFile = fd.read()
            fd.close
            sql = sqlFile.format(date_from, date_to)
#            print(sql)
            try:
                curs.execute(sql)
                return curs.fetchall()
            except jaydebeapi.DatabaseError as exc:
                print(sql)
                raise
            except Exception:
                raise

def executeScriptsFromFile(filename):

    with jaydebeapi.connect(
                'oracle.jdbc.driver.OracleDriver',
                'jdbc:oracle:thin:de3at/bardthebowman@de-oracle.chronosavant.ru:1521/deoracle',
                ['de3at','bardthebowman'],
                '/home/de3at/ojdbc8.jar') as conn:

        with conn.cursor() as curs:
            # Open and read the file as a single buffer
            fd = open(filename, 'r')
            sqlFile = fd.read()
            fd.close()
            # all SQL commands (split on ';')
            sqlCommands = sqlFile.split(';')
            # Execute every command from the input file
            for command in sqlCommands:
                if len(command) > 5:
                    try:
                         curs.execute(command)
                    except jaydebeapi.DatabaseError as exc:
                         print(command)
                         raise
                    except Exception:
                         raise
