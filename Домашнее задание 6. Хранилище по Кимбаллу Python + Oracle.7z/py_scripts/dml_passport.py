#! /usr/bin/env python3
import pandas as pd
import jaydebeapi

df = pd.read_excel('/home/de3at/baratin/passports/full_passports_2022-03-07_22-16-41.xlsx')

print('Try to get passports:')

with jaydebeapi.connect(
            'oracle.jdbc.driver.OracleDriver',
            'jdbc:oracle:thin:de3at/bardthebowman@de-oracle.chronosavant.ru:1521/deoracle',
            ['de3at','bardthebowman'],
            '/home/de3at/ojdbc8.jar') as conn:

    with conn.cursor() as curs:

        print(' Try to truncate passport tables')
        sql_truncate_table = 'truncate table kela_stg_passports'              
        try:
            curs.execute(sql_truncate_table)
        except jaydebeapi.DatabaseError as exc:
            print('!ERROR!: ' + str(exc))
        sql_truncate_table = 'truncate table kela_dwh_dim_passports'
        try:
            curs.execute(sql_truncate_table)
        except jaydebeapi.DatabaseError as exc:
            print('!ERROR!: ' + str(exc))

        print(' Try to fill passport stage')
        sql_insert_stg = '''insert into de3at.kela_stg_passports (last_name, first_name, patronymic, 
            sex, date_of_birth, passport_number, passport_date, passport_issue) values (:1, :2, :3, :4, to_date(:5, 'DD.MM.YYYY'), :6, to_date(:7, 'DD.MM.YYYY'), :8)'''
        df_list = df.fillna('').values.tolist()
        try:
            curs.executemany(sql_insert_stg, df_list)
        except jaydebeapi.DatabaseError as exc:
            print('!ERROR!: ' + str(exc))        

        print(' Try to insert data in passport dim')
        sql_insert_dim = '''insert into de3at.kela_dwh_dim_passports (first_name, last_name, patronymic, 
                sex, date_of_birth, passport_number, passport_date, passport_issue) 
            select           
                first_name, last_name, patronymic, 
                case
                    when sex = 'МУЖ' then 'M'
                    when sex = 'ЖЕН' then 'F'
                    else 'U'
                end,
                date_of_birth, passport_number, passport_date, passport_issue
            from
                de3at.kela_stg_passports '''
        try:
            curs.execute(sql_insert_dim)
        except jaydebeapi.DatabaseError as exc:
            print('!ERROR!: ' + str(exc))
